<form method="GET" action="{{ route('rooms.index') }}" class="mb-3">
  <input type="text" name="q" value="{{ old('q', $q) }}" placeholder="Buscar sala o ubicación">
  <button type="submit">Buscar</button>
</form>

@if(!empty($q))
  <p>Mostrando resultados para: <strong>{{ $q }}</strong></p>
@endif

@forelse($rooms as $room)
  <div>#{{ $room->id }} — {{ $room->name }} ({{ $room->status }}) — {{ $room->location }}</div>
@empty
  <p>No hay salas.</p>
@endforelse

{{ $rooms->links() }}
