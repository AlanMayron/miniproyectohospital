<?php
// routes/web.php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\ProfileController;

Route::get('/', fn () => redirect('/rooms'));

Route::middleware('auth')->group(function () {
    Route::get('/rooms', [RoomController::class, 'index'])->name('rooms.index');
    Route::resource('rooms', RoomController::class)->except(['index']);
    Route::post('/rooms/{room}/restore', [RoomController::class, 'restore'])->withTrashed()->name('rooms.restore');
    Route::delete('/rooms/{room}/force-delete', [RoomController::class, 'forceDelete'])->withTrashed()->name('rooms.force-delete');

    // Breeze profile (evita error profile.edit)
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // opcional: dashboard → rooms
    Route::get('/dashboard', fn () => redirect('/rooms'))->name('dashboard');
});

require __DIR__.'/auth.php';
