{{-- resources/views/rooms/index.blade.php --}}
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl">
            Salas
        </h2>
    </x-slot>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            {{-- tu contenido --}}
            @if($rooms->count())
                <div class="space-y-2">
                    @foreach($rooms as $room)
                        <div class="p-3 border rounded">
                            #{{ $room->id }} — {{ $room->name }} ({{ $room->status }})
                        </div>
                    @endforeach
                </div>
                <div class="mt-3">
                    {{ $rooms->withQueryString()->links() }}
                </div>
            @else
                <p>No hay salas.</p>
            @endif
        </div>
    </div>
</x-app-layout>
