<?php
use Illuminate\Http\Request;
use App\Models\Room;

class RoomController extends Controller
{
    public function index(Request $request)
    {
        $q = (string) $request->query('q', '');

        $rooms = Room::query()
            ->when($q !== '', function ($query) use ($q) {
                // Estás en Postgres (se ve en el log), usa ILIKE:
                $query->where(function ($w) use ($q) {
                    $w->where('name', 'ilike', "%{$q}%")
                      ->orWhere('location', 'ilike', "%{$q}%");
                });
            })
            ->orderBy('id')
            ->paginate(10)
            ->withQueryString(); // mantiene ?q=... en la paginación

        return view('rooms.index', compact('rooms', 'q'));
    }
}
